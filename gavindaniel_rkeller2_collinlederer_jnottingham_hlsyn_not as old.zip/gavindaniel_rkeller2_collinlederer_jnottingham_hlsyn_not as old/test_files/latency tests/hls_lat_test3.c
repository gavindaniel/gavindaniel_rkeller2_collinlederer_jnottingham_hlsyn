input Int16 a, b, c, d, e, f, g, h

output Int16 i, j, k, l

i = a * b
j = c * d
k = e * f
l = g * h
