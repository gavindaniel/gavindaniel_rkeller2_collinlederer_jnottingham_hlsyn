# 1) Authors: Gavin Daniel, Jason Nottingham, Robert Keller, Collin Lederer
#    NetIDs: gavindaniel_rkeller2_collinlederer_jnottingham
#    Project: hlsyn

# 2) ECE 474A (574A for Jason)
#
# 3) Our program takes a behavioral netlist and parses the like .c file using
#    C++ to convert the .c file and output the converted verilog code to 
#    a high level state machine .v file that can be synthesized and executed in Vivado.
#
# 4) Gavin	- Worked on the parsing of the input file and creating objects
# 				from the parsed lines from the input file and outputting the .v file.
#    Bob	- Worked on what outputs should look like and helped debug code 
#				in Vivado to make sure our code compiled and could be synthesized in Vivado. 
#    Collin	- Worked on hte Force Directed Scheduling and analyzing the code that is read in
#				and calculate the graphs to be outputted for the state machines. 
#    Jason	- Worked on hte Force Directed Scheduling and analyzing the code that is read in
#				and calculate the graphs to be outputted for the state machines. 

